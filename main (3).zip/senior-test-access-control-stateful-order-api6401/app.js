// فایل app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = 3000;

// حالت داخلی سفارش
let orderState = 'pending'; // pending, approved, shipped, canceled

// کاربران نمونه و نقش‌ها
const users = {
  'admin1': { password: 'adminpass', role: 'admin' },
  'manager1': { password: 'managerpass', role: 'manager' },
  'user1': { password: 'userpass', role: 'user' }
};

// توکن‌های صادرشده
const issuedTokens = {};

function generateToken(username, role) {
  // توکن ساده با زمان انقضا
  const token = crypto.randomBytes(16).toString('hex');
  issuedTokens[token] = {
    username,
    role,
    expires: Date.now() + 20 * 60 * 1000 // 20 دقیقه
  };
  return token;
}

function verifyToken(token) {
  if (!token || !issuedTokens[token]) return null;
  const data = issuedTokens[token];
  if (Date.now() > data.expires) return null;
  return data;
}

// ورود و دریافت توکن
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!users[username] || users[username].password !== password) {
    return res.status(401).json({ error: 'نام کاربری یا رمز اشتباه است.' });
  }
  const token = generateToken(username, users[username].role);
  res.json({ token, role: users[username].role });
});

// مشاهده وضعیت سفارش
app.get('/api/order/state', (req, res) => {
  const token = req.headers['authorization'];
  const user = verifyToken(token);
  if (!user) return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده.' });
  res.json({ state: orderState });
});

// تغییر وضعیت سفارش (فقط مدیر و ادمین)
app.post('/api/order/approve', (req, res) => {
  const token = req.headers['authorization'];
  const user = verifyToken(token);
  if (!user) return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده.' });
  if (orderState !== 'pending') {
    return res.status(409).json({ error: 'سفارش در وضعیت مناسب برای تایید نیست.' });
  }
  if (user.role !== 'manager' && user.role !== 'admin') {
    return res.status(403).json({ error: 'دسترسی کافی ندارید.' });
  }
  orderState = 'approved';
  res.json({ state: orderState });
});

// ارسال سفارش (فقط ادمین، فقط اگر approved)
app.post('/api/order/ship', (req, res) => {
  const token = req.headers['authorization'];
  const user = verifyToken(token);
  if (!user) return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده.' });
  if (orderState !== 'approved') {
    return res.status(409).json({ error: 'سفارش باید ابتدا تایید شود.' });
  }
  if (user.role !== 'admin') {
    return res.status(403).json({ error: 'دسترسی کافی ندارید.' });
  }
  orderState = 'shipped';
  res.json({ state: orderState });
});

// لغو سفارش (همه نقش‌ها، فقط اگر pending یا approved)
app.post('/api/order/cancel', (req, res) => {
  const token = req.headers['authorization'];
  const user = verifyToken(token);
  if (!user) return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده.' });
  if (orderState !== 'pending' && orderState !== 'approved') {
    return res.status(409).json({ error: 'سفارش قابل لغو نیست.' });
  }
  orderState = 'canceled';
  res.json({ state: orderState });
});

// مشاهده تاریخچه سفارش (فقط مدیر و ادمین)
app.get('/api/order/history', (req, res) => {
  const token = req.headers['authorization'];
  const user = verifyToken(token);
  if (!user) return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده.' });
  if (user.role !== 'manager' && user.role !== 'admin') {
    return res.status(403).json({ error: 'دسترسی کافی ندارید.' });
  }
  // تاریخچه نمایشی
  res.json({ history: [
    { state: 'pending', time: '2024-06-01T10:00:00Z' },
    { state: orderState, time: new Date().toISOString() }
  ] });
});

app.listen(PORT, () => {
  console.log(`Order API running on port ${PORT}`);
});
