// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const PORT = 3000;

// In-memory state
const orders = {};
const inventory = {
  'itemA': 5,
  'itemB': 3
};

// Helper: generate orderId
function generateOrderId() {
  return crypto.randomBytes(3).toString('hex');
}

// 1. Create Order
app.post('/api/order', (req, res) => {
  const { customer, item, quantity } = req.body;
  if (!customer || !item || !quantity || typeof quantity !== 'number' || quantity <= 0) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  if (!inventory[item]) {
    return res.status(400).json({ error: 'Item not found' });
  }
  if (inventory[item] < quantity) {
    return res.status(409).json({ error: 'Insufficient stock' });
  }
  const orderId = generateOrderId();
  orders[orderId] = {
    orderId,
    customer,
    item,
    quantity,
    status: 'CREATED',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  // Reserve inventory
  inventory[item] -= quantity;
  return res.status(201).json({ orderId, status: 'CREATED' });
});

// 2. Approve Order
app.post('/api/order/:orderId/approve', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.status !== 'CREATED') {
    return res.status(409).json({ error: 'Order not in CREATED state' });
  }
  order.status = 'APPROVED';
  order.updatedAt = Date.now();
  return res.status(200).json({ orderId, status: 'APPROVED' });
});

// 3. Cancel Order
app.post('/api/order/:orderId/cancel', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.status === 'CANCELLED') {
    return res.status(409).json({ error: 'Order already cancelled' });
  }
  // Only CREATED or APPROVED can be cancelled
  if (order.status !== 'CREATED' && order.status !== 'APPROVED') {
    return res.status(409).json({ error: 'Order cannot be cancelled at this stage' });
  }
  // Return inventory if not shipped
  inventory[order.item] += order.quantity;
  order.status = 'CANCELLED';
  order.updatedAt = Date.now();
  return res.status(200).json({ orderId, status: 'CANCELLED' });
});

// 4. Ship Order
app.post('/api/order/:orderId/ship', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.status !== 'APPROVED') {
    return res.status(409).json({ error: 'Order not in APPROVED state' });
  }
  order.status = 'SHIPPED';
  order.updatedAt = Date.now();
  return res.status(200).json({ orderId, status: 'SHIPPED' });
});

// 5. Get Order
app.get('/api/order/:orderId', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  return res.status(200).json(order);
});

// 6. Get Inventory
app.get('/api/inventory', (req, res) => {
  return res.status(200).json(inventory);
});

// 7. Reset State (برای تست)
app.post('/api/reset', (req, res) => {
  Object.keys(orders).forEach(k => delete orders[k]);
  inventory['itemA'] = 5;
  inventory['itemB'] = 3;
  return res.status(200).json({ ok: true });
});

app.listen(PORT, () => {
  console.log('Order Processing API running on port', PORT);
});