// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// In-memory state
const orders = {};
const users = {};
const inventory = {
  'itemA': 10,
  'itemB': 8,
  'itemC': 6
};

// Helper: Generate unique orderId
function generateOrderId() {
  return crypto.randomBytes(6).toString('hex');
}

// Helper: Simulate payment
function processPayment(userId, amount) {
  if (!users[userId]) return false;
  if (users[userId].balance < amount) return false;
  users[userId].balance -= amount;
  return true;
}

// Register user
app.post('/api/register', (req, res) => {
  const { username, balance } = req.body;
  if (!username || typeof balance !== 'number') {
    return res.status(400).json({ error: 'Invalid input' });
  }
  if (Object.values(users).find(u => u.username === username)) {
    return res.status(409).json({ error: 'Username already exists' });
  }
  const userId = crypto.randomBytes(4).toString('hex');
  users[userId] = { username, balance };
  res.status(201).json({ userId });
});

// Place order (Stateful: must be registered)
app.post('/api/order', (req, res) => {
  const { userId, items } = req.body;
  if (!userId || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  if (!users[userId]) {
    return res.status(403).json({ error: 'User not registered' });
  }
  // Check inventory
  for (const { item, qty } of items) {
    if (!inventory[item] || inventory[item] < qty || qty <= 0) {
      return res.status(400).json({ error: 'Invalid or insufficient inventory' });
    }
  }
  const orderId = generateOrderId();
  orders[orderId] = {
    userId,
    items,
    status: 'pending',
    total: items.reduce((sum, { item, qty }) => sum + qty * 10000, 0),
    createdAt: Date.now()
  };
  res.status(201).json({ orderId });
});

// Confirm order (Stateful: must be pending)
app.post('/api/order/:orderId/confirm', (req, res) => {
  const { userId } = req.body;
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.userId !== userId) {
    return res.status(403).json({ error: 'User mismatch' });
  }
  if (order.status !== 'pending') {
    return res.status(409).json({ error: 'Order not pending' });
  }
  // Reserve inventory
  for (const { item, qty } of order.items) {
    if (inventory[item] < qty) {
      return res.status(409).json({ error: 'Inventory changed, please re-order' });
    }
  }
  for (const { item, qty } of order.items) {
    inventory[item] -= qty;
  }
  order.status = 'confirmed';
  res.json({ orderId, status: order.status });
});

// Pay for order (Stateful: must be confirmed)
app.post('/api/order/:orderId/pay', (req, res) => {
  const { userId } = req.body;
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.userId !== userId) {
    return res.status(403).json({ error: 'User mismatch' });
  }
  if (order.status !== 'confirmed') {
    return res.status(409).json({ error: 'Order not confirmed' });
  }
  // Simulate payment
  if (!processPayment(userId, order.total)) {
    return res.status(402).json({ error: 'Insufficient funds' });
  }
  order.status = 'paid';
  res.json({ orderId, status: order.status });
});

// Get order status
app.get('/api/order/:orderId/status', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json({ orderId, status: order.status });
});

// Cancel order (Stateful: only pending or confirmed)
app.post('/api/order/:orderId/cancel', (req, res) => {
  const { userId } = req.body;
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  if (order.userId !== userId) {
    return res.status(403).json({ error: 'User mismatch' });
  }
  if (order.status === 'paid') {
    return res.status(409).json({ error: 'Cannot cancel paid order' });
  }
  if (order.status === 'cancelled') {
    return res.status(409).json({ error: 'Order already cancelled' });
  }
  // Return inventory if already confirmed
  if (order.status === 'confirmed') {
    for (const { item, qty } of order.items) {
      inventory[item] += qty;
    }
  }
  order.status = 'cancelled';
  res.json({ orderId, status: order.status });
});

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.listen(3000, () => {
  console.log('API server running on port 3000');
});
