// Express app with stateful order flow
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');
const app = express();
app.use(cors());
app.use(bodyParser.json());

// State store (in-memory)
const orders = {};

// State machine:
// States: 'created', 'confirmed', 'paid', 'cancelled'
// Transitions: create -> confirm -> pay -> complete/cancel

app.post('/api/order/create', (req, res) => {
  const { customer, items } = req.body;
  if (!customer || !items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  const orderId = crypto.randomBytes(8).toString('hex');
  orders[orderId] = {
    customer,
    items,
    state: 'created',
    history: [{ state: 'created', ts: Date.now() }]
  };
  return res.status(201).json({ orderId, state: 'created' });
});

app.post('/api/order/confirm', (req, res) => {
  const { orderId } = req.body;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state !== 'created') {
    return res.status(409).json({ error: 'Order not in created state', state: order.state });
  }
  order.state = 'confirmed';
  order.history.push({ state: 'confirmed', ts: Date.now() });
  return res.status(200).json({ orderId, state: 'confirmed' });
});

app.post('/api/order/pay', (req, res) => {
  const { orderId, paymentInfo } = req.body;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state !== 'confirmed') {
    return res.status(409).json({ error: 'Order not in confirmed state', state: order.state });
  }
  if (!paymentInfo || !paymentInfo.cardNumber) {
    return res.status(400).json({ error: 'Invalid payment info' });
  }
  // Simulate payment
  if (paymentInfo.cardNumber === '0000') {
    order.state = 'cancelled';
    order.history.push({ state: 'cancelled', ts: Date.now() });
    return res.status(402).json({ error: 'Payment rejected', state: 'cancelled' });
  }
  order.state = 'paid';
  order.history.push({ state: 'paid', ts: Date.now() });
  return res.status(200).json({ orderId, state: 'paid' });
});

app.get('/api/order/status/:orderId', (req, res) => {
  const order = orders[req.params.orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  return res.status(200).json({ orderId: req.params.orderId, state: order.state, history: order.history });
});

app.post('/api/order/cancel', (req, res) => {
  const { orderId } = req.body;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state === 'paid') {
    return res.status(403).json({ error: 'Cannot cancel paid order', state: order.state });
  }
  if (order.state === 'cancelled') {
    return res.status(409).json({ error: 'Order already cancelled', state: order.state });
  }
  order.state = 'cancelled';
  order.history.push({ state: 'cancelled', ts: Date.now() });
  return res.status(200).json({ orderId, state: 'cancelled' });
});

app.listen(3000, () => {
  console.log('Stateful order API running on port 3000');
});