// UI logic for order flow
const apiBase = 'http://localhost:3000/api/order';
let orderId = null;
let items = [];

function show(view) {
  document.getElementById('main-view').style.display = 'none';
  document.getElementById('confirm-view').style.display = 'none';
  document.getElementById('pay-view').style.display = 'none';
  document.getElementById('status-view').style.display = 'none';
  document.getElementById(view).style.display = '';
}

// Add item logic
const addItemBtn = document.getElementById('add-item');
addItemBtn.onclick = function() {
  const itemInput = document.getElementById('item');
  if (itemInput.value.trim()) {
    items.push(itemInput.value.trim());
    const li = document.createElement('li');
    li.textContent = itemInput.value.trim();
    document.getElementById('items-list').appendChild(li);
    itemInput.value = '';
  }
};

// Create order
const orderForm = document.getElementById('order-form');
orderForm.onsubmit = async function(e) {
  e.preventDefault();
  const customer = document.getElementById('customer').value;
  if (!customer || items.length === 0) {
    document.getElementById('create-msg').textContent = 'لطفاً نام مشتری و حداقل یک کالا وارد کنید.';
    return;
  }
  const res = await fetch(apiBase + '/create', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ customer, items })
  });
  const data = await res.json();
  if (res.status === 201) {
    orderId = data.orderId;
    show('confirm-view');
    document.getElementById('create-msg').textContent = '';
  } else {
    document.getElementById('create-msg').textContent = data.error || 'خطا در ایجاد سفارش.';
  }
};

// Confirm order
const confirmBtn = document.getElementById('confirm-order');
confirmBtn.onclick = async function() {
  const res = await fetch(apiBase + '/confirm', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ orderId })
  });
  const data = await res.json();
  if (res.status === 200) {
    show('pay-view');
    document.getElementById('confirm-msg').textContent = '';
  } else {
    document.getElementById('confirm-msg').textContent = data.error || 'خطا در تأیید سفارش.';
  }
};

// Cancel order
const cancelBtn = document.getElementById('cancel-order');
cancelBtn.onclick = async function() {
  const res = await fetch(apiBase + '/cancel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ orderId })
  });
  const data = await res.json();
  if (res.status === 200) {
    show('status-view');
    document.getElementById('status-msg').textContent = 'سفارش لغو شد.';
  } else {
    document.getElementById('confirm-msg').textContent = data.error || 'خطا در لغو سفارش.';
  }
};

// Pay order
const payForm = document.getElementById('pay-form');
payForm.onsubmit = async function(e) {
  e.preventDefault();
  const cardNumber = document.getElementById('card-number').value;
  const res = await fetch(apiBase + '/pay', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ orderId, paymentInfo: { cardNumber } })
  });
  const data = await res.json();
  if (res.status === 200) {
    show('status-view');
    document.getElementById('status-msg').textContent = 'پرداخت موفقیت‌آمیز بود.';
  } else if (res.status === 402) {
    show('status-view');
    document.getElementById('status-msg').textContent = 'پرداخت رد شد. سفارش لغو شد.';
  } else {
    document.getElementById('pay-msg').textContent = data.error || 'خطا در پرداخت.';
  }
};

// New order
const newOrderBtn = document.getElementById('new-order');
newOrderBtn.onclick = function() {
  orderId = null;
  items = [];
  document.getElementById('customer').value = '';
  document.getElementById('item').value = '';
  document.getElementById('items-list').innerHTML = '';
  document.getElementById('create-msg').textContent = '';
  document.getElementById('confirm-msg').textContent = '';
  document.getElementById('pay-msg').textContent = '';
  document.getElementById('status-msg').textContent = '';
  show('main-view');
};